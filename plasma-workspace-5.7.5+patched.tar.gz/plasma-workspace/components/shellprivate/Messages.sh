#! /bin/sh
$XGETTEXT *.cpp */*.cpp -o $podir/plasmashellprivateplugin.pot
