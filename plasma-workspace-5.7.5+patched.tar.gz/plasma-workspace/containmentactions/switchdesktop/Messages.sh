#! /usr/bin/env bash
$XGETTEXT *.cpp -o $podir/plasma_containmentactions_switchdesktop.pot
