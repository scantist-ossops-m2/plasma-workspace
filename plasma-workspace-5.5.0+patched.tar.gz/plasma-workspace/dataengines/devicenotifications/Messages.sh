#! /usr/bin/env bash
$XGETTEXT *.cpp -o $podir/plasma_engine_devicenotifications.pot
